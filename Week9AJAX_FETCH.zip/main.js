document.addEventListener("DOMContentLoaded", ()=> {
  // on page load get first user
  console.log("loaded");
  userRequest();
  let btn = document.querySelector("#nextuser-btn");
  // Event: Btn click -> next rando users

  // THIS BUTTON USES THE FETCH API to return the request
  let fetchbtn = document.querySelector("#fetch");
  fetchbtn.addEventListener("click", function() {
    console.log("fetch");
    let request = fetch("https://randomuser.me/api")
    .then(function(result) {
      return result.json();
    })
    .then(function(data) {
      generateOutput(data);
    })
  })

  // THIS BUTTON USES XMLHttpRequest to return the request
  btn.addEventListener("click", () => {
    userRequest();
  })
  // createNewUser() make AJAX req pass results to generate and finally outyput


  // AJAX request for randomuser: https://randomuser.me/api/
  function userRequest() {
    let xhr = new XMLHttpRequest();
    xhr.open(
      "GET",
      "https://randomuser.me/api",
      true
    );
    xhr.onload = function() {
      if(this.status == 200) {
        let res = JSON.parse(this.responseText);
        generateOutput(res);
      }
    }
    xhr.send();
  }

  // Function to process JS => HTML
  function generateOutput(obj) {
    let user = obj.results[0];
    console.log(user);
    // generate user profile html
    // user img, first + last name, city + country, email
    // user backtick `` (next to tilda~)
    let output = `
    <div class="col-md-12">
    <img src="${user.picture.large}" class="rounded-circle ${user.gender}">
    <h1>${user.name.first} ${user.name.last}</h1>
    <h3 class="font-weight-light">${user.location.city}, ${user.location.country} </h3>
    <h5 class="font-weight-light"><em>${user.email}</em></h5>
    </div>
    `;
    let location = document.querySelector(".useroutput");
    outputHTML(output, location);
    console.log(output);
    console.log(location);
  }

  // Function to output HTML to DOM
  function outputHTML(html, location) {
    location.innerHTML = html;
  }
})
