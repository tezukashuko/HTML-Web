$(document).ready(function() {
  console.log("doc loaded");
//Listeners
  //Gallery img listener
  $(".gallery img").click(function(){
    let currentnode = $(this);
    let src = currentnode.attr("src");
    console.log(src);
    // apply active class to clicked element
    currentnode.addClass("active");
    loadImg(src);
    showLightbox();
  });

  // stop propagation on child elements
  $(".lightbox img").click(function(event) {
    event.stopPropagation();
  })
  $(".lightbox ul").click(function(event) {
    event.stopPropagation();
  })
  // hide lightbox Listener
  $(".lightbox").click(function(){
    hideLightbox();
    $(".gallery img").removeClass("active");
  });

  // listen for click on NEXT tab
  $(".lightbox ul li.next").click(function() {
    cycleImg("next");
  });
  $(".lightbox ul li.prev").click(function() {
    cycleImg("prev");
  });

  function cycleImg(direction) {
    let currentnode = $(".gallery img.active");
    let src,nextnode,onclass,offclass;
    if(direction == "next") {
      console.log("next chosen");
       nextnode = currentnode.next();
       onclass = "leftminus100";
       offclass = "left100";
    } else {
      nextnode = currentnode.prev();
      onclass = "left100";
      offclass = "leftminus100";
    }
    src = nextnode.attr("src");
    
    if(src == null && direction == "next") {
      nextnode = $(".gallery img").first();
      src = nextnode.attr("src");
    } else if (src == null && direction == "prev") {
      nextnode = $(".gallery img").last();
      src = nextnode.attr("src");
    }
    currentnode.removeClass("active");
    nextnode.addClass("active");
    let newnode = "<img src='" + src + "' class='"+ onclass + "'>";
    $(".lightbox .wrapper").append(newnode);
    setTimeout(function() {
      $(".lightbox .wrapper img").last().removeClass(onclass);
      $(".lightbox .wrapper img").first().addClass(offclass);
    }, 10)
    setTimeout(function(){
      $(".lightbox .wrapper img").first().remove();
    }, 300)
  }


  //show the lightbox with fade in
  function showLightbox() {
    $(".lightbox").css("display", "flex");
    setTimeout(function(){
      console.log("lightbox show");
      $(".lightbox").css("opacity", 1);
    }, 10);
  }
  //hide the lightbox with fade out
  function hideLightbox() {
    $(".lightbox").css("opacity", 0);
    setTimeout(function(){
      $(".lightbox").css("display", "none");
    }, 300);
  }
  function loadImg(src) {
    console.log("img loaded");
    $(".lightbox img").attr("src", src);
  }

})
