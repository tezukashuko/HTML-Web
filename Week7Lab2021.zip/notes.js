let b = activeEdits.filter(function(edit){
    if(edit[0].textContent == 2) {
    return true;
    }
})
